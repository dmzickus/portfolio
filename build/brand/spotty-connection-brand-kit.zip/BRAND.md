# Spotty Connection

Now showing. Mostly.

Spotty Connection is the house brand for Dylan's self-hosted "products": the media server, the music server, the photo backups, the retro box, the homelab and whatever comes next. It borrows from an old movie palace. Think a marquee sign with a few burnt-out bulbs, snack-bar amber, and white caps on a warm black screen. The joke lives in the mark: the Wi-Fi symbol is built from marquee bulbs, and a few of them are always dead.

## The name

Spotty Connection is named after Spotty, the lizard we had. When we needed a name for our Wi-Fi network, Dylan came up with "Spotty Connection," and it stuck. Since then it has become the name for everything he runs: the movies, the music, the photos and the rest of the homelab. The dead bulbs in the logo keep the joke going.

## Two modes

One brand, two lighting cues. Pick the mode by audience; everything else is shared.

| | House lights (professional) | Showtime (playful) |
| --- | --- | --- |
| Where | dylanzickus.com by default, resume, LinkedIn, GitHub | Self-hosted services, preshows, dashboards, login screens, stickers, /brand/ |
| Background | Navy (`surface` navy theme) | Marquee black (`surface` dark theme) |
| Type | Space Grotesk headings, mono labels | Bungee + Bebas Neue, mono labels |
| Links | `signal` teal | `concession` amber |
| Marquee touches | Only the mark and its power-on animation | Bulb borders, marquee-sign headings, poster cards, theater status names (Now showing, Coming soon, Intermission, Final curtain, In production) |

**Shared in both:** the hybrid mark, teal = live/links, amber = accent, mono labels, one dead bulb somewhere, the power-on animation.

On dylanzickus.com a footer switch flips between them (and clicking the hero logo five times does too). The choice is remembered per browser; first-time visitors get House lights.

## The mark

- **Primary mark (the hybrid).** A Wi-Fi symbol with thick round-capped arcs and a soft glow. Three of its gaps each hold one burnt-out marquee bulb (`dud`). The inner and middle arcs are `signal` teal; the outer arc and the access-point dot are `concession` amber.
- **The duds are fixed.** There's one in the middle arc's gap and two in the outer arc's gaps. Never light them, add more, or move them. That pattern *is* the logo: the connection is spotty because a few bulbs are dead.
- **Simple mark (favicon).** The same arcs with plain dropout gaps and no bulbs. Use it at 48 px and below (favicons, tab icons, tray icons).
- **Glow.** On by default on the dark and navy themes, off on the light/print and mono versions.
- **Clear space.** Keep two access-point-dot diameters clear on every side. The mark sits on `surface`, never on a photo without a `surface` plate behind it.
- **Don't** recolor arcs outside the theme values, rotate the mark, add a drop shadow, outline the wordmark, or stretch any lockup.

## Lockups

| Lockup | Use it for |
| --- | --- |
| Horizontal (mark + stacked wordmark) | Site headers, login screens, README banners, email footers |
| Stacked (mark over wordmark) | Splash screens, square slots, Jellyfin/Homarr tiles, stickers |
| Wordmark only | Tight horizontal spaces, footers, where the mark already appears nearby |
| Marquee badge (secondary logo) | Fun placements: sign boards, 404 pages, sticker sheets, "Now Showing" panels |
| App icon / favicon | Browser tabs, PWA manifests, Homarr/HA dashboards, phone home screens |

Every lockup comes in **dark** (primary), **navy** (backup), **light** (paper/print) and **mono** (white, for laser-cutting, embroidery, watermarks).

## Sub-brands

Each product gets the full wordmark plus its name in Bebas Neue, tracked +0.32em, between two accent rules in its own color. This reuses the Cinemas preshow card layout.

| Sub-brand | Accent token | Covers |
| --- | --- | --- |
| SPOTTY CONNECTION **CINEMAS** | `sub-cinemas` amber | Jellyfin, preshows, Seerr ("Now Showing") |
| SPOTTY CONNECTION **RADIO** | `sub-radio` teal | Navidrome, Lidarr, Music Assistant |
| SPOTTY CONNECTION **PHOTOS** | `sub-photos` rose | Immich, restic backups |
| SPOTTY CONNECTION **ARCADE** | `sub-arcade` violet | The couch retro box, RomM |
| SPOTTY CONNECTION **LABS** | `sub-labs` phosphor green | ESP builds, experiments, the Pi cluster |
| SPOTTY CONNECTION **OPS** | `sub-ops` curtain red | Daily homelab report, status pages, monitoring |

**Adding a new sub-brand:** pick one accent that isn't close to an existing one, has at least 3:1 contrast on `surface` dark, and stays readable in the darkened light-theme version (the generator mixes 42% toward `ink` automatically). Then run the generator:

```bash
python3 build.py --sub BOOKS --accent "#7ec4f0"   # horizontal/stacked (dark+light), badge, and a 1080p sting
```

The name is ONE word, ALL CAPS, ideally 4–8 letters. Nouns from the movie palace or radio world (REELS, BOOTH, MARQUEE, STATION) fit the voice best.

## Color

- **Dark "Marquee" theme is primary.** It uses `surface` warm black, `ink` projector cream, and `signal` and `concession` as accents. Accents are for marks, rules, links and highlights. Long text stays `ink`/`ink-muted`.
- **Navy is the backup** (the original Spotty Connection icon colors). Use it when something needs to sit next to a cool-toned UI.
- **Paper (light)** is for print and light UIs. There, `signal` and `concession` are darkened versions that pass only at 24px+, so body text and links stay `ink`.
- `curtain-red` means ON AIR / alert / OPS. Use it small, never as a big fill.
- `dud` is only for dead bulbs.

## Type

All of these are free Google Fonts. Each has a fallback chain for when it isn't loaded.

| Role | Face | Fallbacks | Rules |
| --- | --- | --- | --- |
| Display / wordmark | **Bungee** | Impact, Arial Black | ALL CAPS, short lines, leading 0.92. The logo itself is outlined, so it never depends on the font. |
| Billing / sub-brands | **Bebas Neue** | Oswald, Arial Narrow | Caps, tracked +0.32em for sub-brand names, +0.06em for headlines |
| Labels / UI chrome | **IBM Plex Mono** 500 | JetBrains Mono, ui-monospace | Small caps-style labels, timestamps, code |
| Body | **IBM Plex Sans** | system-ui | Paragraphs only |
| Headless (servers, ffmpeg) | **DejaVu Sans Bold / Mono** | — | For generated cards where Google Fonts aren't installed (the preshow script already uses this) |

## Motion

- **Power-on sting** (1080p MP4, 5 s): the dot lights first, then each ring of arcs powers on outward, the dud bulbs flash and die, and the wordmark fades in. A CINEMAS version adds the sub-brand line, made for the Jellyfin preshow logo card.
- **Animated mark** (SVG, loops): the arcs breathe gently and one dud bulb flickers back to life for a moment about every 6 s. Pure CSS, works in an `<img>`, and respects `prefers-reduced-motion`.
- **GIFs**, for places that won't play video (READMEs, Discord): `sting-mark-360.gif` (just the mark) and `sting-640.gif` (full frame with the wordmark).
- Motion is warm and analog: eased fades and flickers. No slides, bounces or zooms.

## Voice

Wry and old-cinema. Signs say NOW SHOWING, INTERMISSION, PLEASE STAND BY, TECHNICAL DIFFICULTIES. Error pages are a gift: "We're experiencing a spotty connection." Keep copy short, in caps for signage and sentence case for everything else.

## Where to sneak it in

Favicons and PWA icons on every self-hosted service. Login and splash screens (Jellyfin, Immich, Navidrome, Homarr). The preshow logo card and library posters. 404 and "stand by" pages. Email report headers (OPS). Home Assistant dashboard headers. GitHub READMEs and social previews. The Tailscale/Cloudflare tunnel landing pages. Stickers for the NAS, the Pi cases and the couch box. A boot splash on the retro box.

## Source of truth

Everything is generated by `build.py`, which outlines all text, so the SVGs need no fonts. It lives in the kit zip with all PNG sizes (16 px to 2400 px). Rebuild the whole kit with `python3 build.py`; it needs `fonttools`, `rsvg-convert` and `ffmpeg`, plus the fonts from `npm i @fontsource/bungee @fontsource/bebas-neue @fontsource/ibm-plex-mono`.
