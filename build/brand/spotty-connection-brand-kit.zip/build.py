#!/usr/bin/env python3
"""Spotty Connection brand kit generator.

Usage:
  python3 build.py                         # build the whole kit into out/
  python3 build.py --sub ARCADE --accent "#a68cf2"   # add/refresh one sub-brand lockup
All text is converted to outlines, so every SVG is self-contained (no font installs needed).
"""
import argparse, json, math, os, re, subprocess, sys
from fontTools.ttLib import TTFont
from fontTools.pens.svgPathPen import SVGPathPen
from fontTools.pens.transformPen import TransformPen

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "out")
FS = os.path.join(HERE, "node_modules/@fontsource")

# ---------------------------------------------------------------- tokens
C = {
    "marquee":  "#0d0b0a",   # warm near-black (the Cinemas card background)
    "booth":    "#1a1614",   # raised surface
    "cream":    "#f3e9d2",   # projector cream: primary text / wordmark
    "teal":     "#4fd1c5",   # signal teal
    "amber":    "#f6ad55",   # concession amber
    "dud":      "#3a322c",   # a burnt-out bulb
    "dud_rim":  "#5a4e44",
    "red":      "#d9483b",   # curtain red: sparingly (on-air, alerts)
    # backup theme: the original navy
    "navy":     "#1b2440", "navy_deep": "#0e1326",
    # light / print backup
    "paper":    "#f3e9d2", "ink": "#1a1614", "teal_ink": "#1f8a80", "amber_ink": "#c46f12",
}
SUBS = {  # sub-brand: accent
    "CINEMAS": C["amber"], "RADIO": C["teal"], "PHOTOS": "#ef8f9f",
    "ARCADE": "#a68cf2", "LABS": "#9be07a", "OPS": C["red"],
}
THEMES = {  # name: (background, wordmark, inner/middle bulbs, outer bulbs + dot, dud)
    "dark":  (C["marquee"], C["cream"], C["teal"], C["amber"], C["dud"]),
    "navy":  (C["navy"], C["cream"], C["teal"], C["amber"], "#3a4566"),
    "light": (C["paper"], C["ink"], C["teal_ink"], C["amber_ink"], "#d8ccb2"),
    "mono":  (None, "#ffffff", "#ffffff", "#ffffff", None),
}

# ---------------------------------------------------------------- fonts -> outlines
_fonts = {}
def font(name):
    if name not in _fonts:
        path = {"bungee": "bungee/files/bungee-latin-400-normal.woff",
                "bebas": "bebas-neue/files/bebas-neue-latin-400-normal.woff",
                "mono": "ibm-plex-mono/files/ibm-plex-mono-latin-500-normal.woff"}[name]
        f = TTFont(os.path.join(FS, path))
        _fonts[name] = (f, f.getGlyphSet(), f.getBestCmap(), f["hmtx"], f["head"].unitsPerEm)
    return _fonts[name]

def text_width(s, name, size, track=0.0):
    f, gs, cmap, hmtx, upem = font(name)
    w = sum(hmtx[cmap.get(ord(ch), ".notdef")][0] for ch in s) * size / upem
    return w + track * size * (len(s) - 1)

def text_path(s, name, size, x, y, track=0.0, fill="#fff", anchor="start"):
    """Return an SVG <path> of string s with baseline at y. track = extra spacing in em."""
    f, gs, cmap, hmtx, upem = font(name)
    sc = size / upem
    w = text_width(s, name, size, track)
    if anchor == "middle": x -= w / 2
    elif anchor == "end": x -= w
    pen = SVGPathPen(gs)
    cx = x
    for ch in s:
        g = cmap.get(ord(ch), ".notdef")
        gs[g].draw(TransformPen(pen, (sc, 0, 0, -sc, cx, y)))
        cx += hmtx[g][0] * sc + track * size
    return f'<path fill="{fill}" d="{pen.getCommands()}"/>', w

# ---------------------------------------------------------------- the mark
# Hybrid mark (option A): the favicon's solid arcs, each dropout gap holding one burnt-out bulb.
CX, CY = 256, 382
SEGS = [  # ring, radius, start deg, end deg (135 = left end, 45 = right end)
    (0, 96, 135, 45),
    (1, 170, 135, 82), (1, 170, 58, 45),
    (2, 244, 135, 120), (2, 244, 104, 93), (2, 244, 77, 45),
]
DUDS = [(1, 170, 70), (2, 244, 112), (2, 244, 85)]  # ring, radius, angle: fixed, never "fixed"
STROKE, DUD_R, DOT_R = 44, 17, 38

def _pt(r, deg):
    t = math.radians(deg); return CX + r * math.cos(t), CY - r * math.sin(t)

def _arc(r, a0, a1):
    (x0, y0), (x1, y1) = _pt(r, a0), _pt(r, a1)
    return f"M{x0:.1f} {y0:.1f} A{r} {r} 0 0 1 {x1:.1f} {y1:.1f}"

def mark(uid="m", theme="dark", glow=True, levels=None, dot_level=1.0, dud_levels=None):
    """Hybrid Wi-Fi mark in a 512x512 box.
    levels: optional {seg_index: 0..1}; dud_levels: optional {dud_index: 0..1} (a dud briefly lit, for animation)."""
    bg, ink, inner, outer, dud = THEMES[theme]
    flat = theme == "mono"
    glow = glow and not flat and theme != "light"
    g_glow, g_main = [], []
    for k, (ri, r, a0, a1) in enumerate(SEGS):
        lvl = 1.0 if levels is None else levels.get(k, 1.0)
        col = outer if ri == 2 else inner
        d = _arc(r, a0, a1)
        if not flat:  # unlit tube underneath so the shape exists before power-on
            g_main.append(f'<path d="{d}" stroke="{dud}" stroke-width="{STROKE}" fill="none" stroke-linecap="round"/>')
        if lvl > 0.01:
            g_main.append(f'<path d="{d}" stroke="{col}" stroke-width="{STROKE}" fill="none" stroke-linecap="round" opacity="{lvl:.2f}"/>')
            if glow: g_glow.append(f'<path d="{d}" stroke="{col}" stroke-width="{STROKE+12}" fill="none" stroke-linecap="round" opacity="{0.45*lvl:.2f}"/>')
    for k, (ri, r, a) in enumerate(DUDS):
        x, y = _pt(r, a)
        col = outer if ri == 2 else inner
        lit = 0.0 if dud_levels is None else dud_levels.get(k, 0.0)
        if flat:
            g_main.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{DUD_R-2.5}" fill="none" stroke="{col}" stroke-width="5"/>')
            continue
        rim = C["dud_rim"] if theme == "dark" else dud
        g_main.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{DUD_R}" fill="{dud}" stroke="{rim}" stroke-width="2"/>')
        if lit > 0.01:
            g_main.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{DUD_R}" fill="{col}" opacity="{lit:.2f}"/>')
            if glow: g_glow.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="{DUD_R+6}" fill="{col}" opacity="{0.5*lit:.2f}"/>')
    if not flat: g_main.append(f'<circle cx="{CX}" cy="{CY}" r="{DOT_R}" fill="{dud}"/>')
    g_main.append(f'<circle cx="{CX}" cy="{CY}" r="{DOT_R}" fill="{outer}" opacity="{1 if flat else dot_level:.2f}"/>')
    if glow: g_glow.append(f'<circle cx="{CX}" cy="{CY}" r="{DOT_R+8}" fill="{outer}" opacity="{0.5*dot_level:.2f}"/>')
    defs = (f'<defs><filter id="glow{uid}" filterUnits="userSpaceOnUse" x="-100" y="-100" width="712" height="712">'
            f'<feGaussianBlur stdDeviation="9"/></filter></defs>') if glow else ""
    glow_g = f'<g filter="url(#glow{uid})">{"".join(g_glow)}</g>' if g_glow else ""
    return defs + glow_g + "".join(g_main)

def simple_mark(theme="dark"):
    """Secondary mark: solid arcs with dropouts, for 16-48 px where bulbs turn to mush."""
    bg, ink, inner, outer, dud = THEMES[theme]
    def arc(r):
        a0, a1 = math.radians(135), math.radians(45)
        return f"M{CX+r*math.cos(a0):.1f} {CY-r*math.sin(a0):.1f} A{r} {r} 0 0 1 {CX+r*math.cos(a1):.1f} {CY-r*math.sin(a1):.1f}"
    L = lambda r: math.pi * r / 2
    return (f'<g fill="none" stroke-linecap="round" stroke-width="44">'
            f'<path d="{arc(96)}" stroke="{inner}"/>'
            f'<path d="{arc(170)}" stroke="{inner}" stroke-dasharray="{L(170)*.55:.0f} {L(170)*.22:.0f} 999"/>'
            f'<path d="{arc(244)}" stroke="{outer}" stroke-dasharray="{L(244)*.18:.0f} {L(244)*.16:.0f} {L(244)*.12:.0f} {L(244)*.18:.0f} 999"/>'
            f'</g><circle cx="{CX}" cy="{CY}" r="38" fill="{outer}"/>')

# ---------------------------------------------------------------- wordmarks
def wordmark_stacked(x, y, width, ink):
    """'SPOTTY' over 'CONNECTION', both justified to `width`. y = top. Returns (svg, height)."""
    out, cy = [], y
    for word, gap in (("SPOTTY", 0.10), ("CONNECTION", 0.0)):
        base = text_width(word, "bungee", 100)
        size = width / base * 100 * (1 - gap * 0)  # scale to full width
        # Bungee caps are ~0.72em tall
        cy += size * 0.74
        p, _ = text_path(word, "bungee", size, x, cy, fill=ink)
        out.append(p); cy += size * 0.16
    return "".join(out), cy - y - 0

def svg(w, h, body, bg=None, rx=0):
    rect = f'<rect width="{w}" height="{h}" rx="{rx}" fill="{bg}"/>' if bg else ""
    return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}">{rect}{body}</svg>\n'

def placed(inner, x, y, s):
    return f'<g transform="translate({x:.1f} {y:.1f}) scale({s:.4f})">{inner}</g>'

# ---------------------------------------------------------------- assets
def write(path, content):
    full = os.path.join(OUT, path); os.makedirs(os.path.dirname(full), exist_ok=True)
    open(full, "w").write(content); return full

def png(svgpath, *sizes, square=True):
    for s in sizes:
        dst = svgpath.replace("/svg/", "/png/").replace(".svg", f"-{s}.png")
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        args = ["-w", str(s)] + (["-h", str(s)] if square else [])
        subprocess.run(["rsvg-convert", *args, svgpath, "-o", dst], check=True)

def lockup_horizontal(theme, sub=None, accent=None, bgfill=True):
    bg, ink, *_ = THEMES[theme]
    ms, pad, ww = 300, 40, 620
    wm, wh = wordmark_stacked(0, 0, ww, ink)
    sub_h = 92 if sub else 0
    H = max(ms, wh + sub_h) + 2 * pad
    wy = (H - (wh + sub_h)) / 2
    m = placed(mark("h" + theme, theme), pad - 10, (H - ms) / 2 + 8, ms / 512)
    wx = pad + ms * 0.95
    wm, wh = wordmark_stacked(wx, wy, ww, ink)
    extra = ""
    if sub:
        acc = accent or SUBS.get(sub, C["amber"])
        ty = wy + wh + 72
        p, tw = text_path(sub, "bebas", 64, wx + ww / 2, ty, track=0.32, fill=acc, anchor="middle")
        side = (ww - tw) / 2 - 24
        extra = (f'<rect x="{wx:.0f}" y="{ty-28:.0f}" width="{side:.0f}" height="5" fill="{acc}"/>'
                 f'<rect x="{wx+ww-side:.0f}" y="{ty-28:.0f}" width="{side:.0f}" height="5" fill="{acc}"/>' + p)
    W = wx + ww + pad
    return svg(int(W), int(H), m + wm + extra, bg if (bgfill and bg) else None)

def lockup_stacked(theme, sub=None, accent=None, bgfill=True):
    bg, ink, *_ = THEMES[theme]
    W = 800
    m = placed(mark("s" + theme, theme), (W - 440) / 2, 10, 440 / 512)
    wm, wh = wordmark_stacked(80, 400, W - 160, ink)
    H = 400 + wh + 50
    extra = ""
    if sub:
        acc = accent or SUBS.get(sub, C["amber"])
        ty = 400 + wh + 70
        p, tw = text_path(sub, "bebas", 76, W / 2, ty, track=0.32, fill=acc, anchor="middle")
        side = (W - 160 - tw) / 2 - 28
        extra = (f'<rect x="80" y="{ty-33:.0f}" width="{side:.0f}" height="5" fill="{acc}"/>'
                 f'<rect x="{W-80-side:.0f}" y="{ty-33:.0f}" width="{side:.0f}" height="5" fill="{acc}"/>' + p)
        H = ty + 55
    return svg(W, int(H), m + wm + extra, bg if (bgfill and bg) else None)

def wordmark_line(theme, bgfill=False):
    bg, ink, *_ = THEMES[theme]
    p, w = text_path("SPOTTY CONNECTION", "bungee", 96, 30, 30 + 96 * 0.74, fill=ink)
    return svg(int(w + 60), int(96 * 0.74 + 60), p, bg if bgfill else None)

def app_icon(theme="dark", simple=False):
    bg, *_ = THEMES[theme]
    body = simple_mark(theme) if simple else mark("i" + theme, theme)
    inner = placed(body, 256 - 0.82 * 256, 256 - 0.82 * 267, 0.82)
    return svg(512, 512, inner, bg, rx=112)

def marquee_badge(theme="dark", label="SPOTTY CONNECTION", sub="NOW SHOWING", accent=None):
    """Secondary logo: a marquee sign with a chasing-bulb border."""
    bg, ink, inner, outer, dud = THEMES[theme]
    acc = accent or outer
    W, H, b = 1000, 520, 34
    parts = [f'<rect x="10" y="10" width="{W-20}" height="{H-20}" rx="40" fill="{C["booth"] if theme=="dark" else bg}" stroke="{acc}" stroke-width="6"/>',
             f'<rect x="{b+26}" y="{b+26}" width="{W-2*b-52}" height="{H-2*b-52}" rx="18" fill="none" stroke="{acc}" stroke-opacity=".35" stroke-width="3"/>']
    # border bulbs
    n_top, n_side = 22, 10
    dead = {5, 17, 26}
    k = 0
    pts = [(b + (W - 2 * b) * i / n_top, b) for i in range(n_top)] + \
          [(W - b, b + (H - 2 * b) * i / n_side) for i in range(n_side)] + \
          [(W - b - (W - 2 * b) * i / n_top, H - b) for i in range(n_top)] + \
          [(b, H - b - (H - 2 * b) * i / n_side) for i in range(n_side)]
    for x, y in pts:
        if k in dead: parts.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="8" fill="{dud}"/>')
        else: parts.append(f'<circle cx="{x:.1f}" cy="{y:.1f}" r="8" fill="{acc if k%2 else ink}"/>')
        k += 1
    parts.append(placed(mark("b" + theme, theme), 92, 112, 300 / 512))
    wm, wh = wordmark_stacked(400, 140, 500, ink)
    parts.append(wm)
    p, tw = text_path(sub, "bebas", 58, 650, 140 + wh + 66, track=0.3, fill=acc, anchor="middle")
    parts.append(p)
    return svg(W, H, "".join(parts))

# ---------------------------------------------------------------- animation
def ease(t): t = max(0, min(1, t)); return t * t * (3 - 2 * t)

def anim_levels(t):
    """Power-on: dot, then each ring's tubes; the duds flash and die. Returns (levels, dot, dud_levels)."""
    lv = {}
    for k, (ri, r, a0, a1) in enumerate(SEGS):
        start = 0.55 + ri * 0.45 + (k % 3) * 0.06
        lv[k] = ease((t - start) / 0.2)
    dl = {}
    for k, (ri, r, a) in enumerate(DUDS):
        st = 0.6 + ri * 0.45 + k * 0.07
        seq = [(st, .9), (st + .1, .15), (st + .18, .8), (st + .3, 0), (st + .5, .5), (st + .55, 0)]
        v = 0
        for (ta, va), (tb, vb) in zip(seq, seq[1:]):
            if ta <= t < tb: v = va
        if k == 1 and 3.9 < t < 3.97: v = .6   # one hopeful flicker later on
        dl[k] = v
    return lv, ease((t - 0.15) / 0.25), dl

def render_sting(dur=5.0, fps=24, W=1920, H=1080, sub=None):
    tmp = os.path.join(OUT, "_frames"); os.makedirs(tmp, exist_ok=True)
    bg, ink, *_ = THEMES["dark"]
    acc = SUBS.get(sub, C["amber"]) if sub else C["amber"]
    frames = int(dur * fps)
    for f in range(frames):
        t = f / fps
        lv, dot, dl = anim_levels(t)
        body = placed(mark("a", "dark", levels=lv, dot_level=dot, dud_levels=dl), W / 2 - 230, 120, 460 / 512)
        a = ease((t - 2.2) / 0.6)
        wm, wh = wordmark_stacked(W / 2 - 430, 600, 860, ink)
        body += f'<g opacity="{a:.2f}">{wm}</g>'
        if sub:
            a2 = ease((t - 2.8) / 0.5)
            ty = 600 + wh + 72
            p, tw = text_path(sub, "bebas", 78, W / 2, ty, track=0.32, fill=acc, anchor="middle")
            side = (860 - tw) / 2 - 28
            body += (f'<g opacity="{a2:.2f}"><rect x="{W/2-430}" y="{ty-34}" width="{side:.0f}" height="5" fill="{acc}"/>'
                     f'<rect x="{W/2+430-side:.0f}" y="{ty-34}" width="{side:.0f}" height="5" fill="{acc}"/>{p}</g>')
        fade = min(1, (dur - t) / 0.5)
        body = f'<g opacity="{fade:.2f}">{body}</g>'
        sp = os.path.join(tmp, f"f{f:04d}.svg")
        open(sp, "w").write(svg(W, H, body, bg))
        subprocess.run(["rsvg-convert", sp, "-o", sp.replace(".svg", ".png")], check=True)
    name = f"sting{'-' + sub.lower() if sub else ''}"
    os.makedirs(os.path.join(OUT, "video"), exist_ok=True)
    mp4 = os.path.join(OUT, "video", f"{name}-1080p.mp4")
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-framerate", str(fps), "-i", f"{tmp}/f%04d.png",
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "18", "-pix_fmt", "yuv420p", "-movflags", "+faststart", mp4], check=True)
    subprocess.run(["rm", "-rf", tmp])
    return mp4

def animated_svg():
    """Looping SVG: tubes breathe gently, duds flicker now and then. Pure CSS, works in <img>."""
    body = mark("x", "dark")
    k = 0
    def tag(m):
        nonlocal k
        k += 1
        return m.group(0).replace('opacity="1.00"', f'class="lit" style="animation-delay:{-k*0.35:.2f}s"')
    body = re.sub(r'<path d="[^"]+" stroke="#(?:4fd1c5|f6ad55)" stroke-width="44"[^>]*opacity="1.00"/>', tag, body)
    fl = []
    for i, (ri, r, a) in enumerate(DUDS):
        x, y = _pt(r, a); col = C["amber"] if ri == 2 else C["teal"]
        fl.append(f'<circle class="flick" cx="{x:.1f}" cy="{y:.1f}" r="{DUD_R}" fill="{col}" style="animation-delay:{i*2.1:.1f}s"/>')
    css = ('<style>.lit{animation:breathe 3.2s ease-in-out infinite}'
           '@keyframes breathe{0%,100%{opacity:1}50%{opacity:.78}}'
           '.flick{opacity:0;animation:flick 6.3s steps(1) infinite}'
           '@keyframes flick{0%,88%,100%{opacity:0}89%{opacity:.85}90%{opacity:.1}92%{opacity:.6}93%{opacity:0}}'
           '@media (prefers-reduced-motion:reduce){.lit,.flick{animation:none}}</style>')
    return svg(512, 512, css + placed(body + "".join(fl), 256 - 0.82 * 256, 256 - 0.82 * 267, 0.82), C["marquee"], rx=112)

def tokens():
    return {
        "name": "Spotty Connection", "tagline": "Now showing. Mostly.",
        "colors": {k: C[k] for k in ("marquee", "booth", "cream", "teal", "amber", "dud", "red")},
        "backup_themes": {"navy": {"bg": C["navy"], "bg_deep": C["navy_deep"], "text": C["cream"], "accents": [C["teal"], C["amber"]]},
                          "light": {"bg": C["paper"], "text": C["ink"], "accents": [C["teal_ink"], C["amber_ink"]]}},
        "sub_brands": SUBS,
        "fonts": {"display": "Bungee (Google Fonts) — wordmark and big headlines, ALL CAPS",
                  "headline": "Bebas Neue — sub-brand names, tracked +0.3em, between accent rules",
                  "mono": "IBM Plex Mono 500 — labels, UI chrome, captions",
                  "fallbacks": {"display": "Impact, 'Arial Black', sans-serif", "headline": "'Oswald', 'Arial Narrow', sans-serif",
                                "mono": "'JetBrains Mono', ui-monospace, monospace",
                                "headless (ffmpeg/servers)": "DejaVu Sans Bold / DejaVu Sans Mono"}},
    }

# ---------------------------------------------------------------- main
def ink_version(hexc, k=0.42):
    """Darker accent for the cream/light theme (mix toward ink)."""
    a = [int(hexc[i:i+2], 16) for i in (1, 3, 5)]; b = [0x1a, 0x16, 0x14]
    return "#" + "".join(f"{round(x*(1-k)+y*k):02x}" for x, y in zip(a, b))

def build_sub(sub, accent):
    SUBS[sub] = accent
    for th in ("dark", "light"):
        acc = accent if th == "dark" else ink_version(accent)
        p = write(f"svg/sub/{sub.lower()}-horizontal-{th}.svg", lockup_horizontal(th, sub, acc)); png(p, 1200, square=False)
        p = write(f"svg/sub/{sub.lower()}-stacked-{th}.svg", lockup_stacked(th, sub, acc)); png(p, 800, square=False)
    p = write(f"svg/sub/{sub.lower()}-badge.svg", marquee_badge("dark", sub=sub, accent=accent)); png(p, 1000, square=False)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--sub"); ap.add_argument("--accent"); ap.add_argument("--no-video", action="store_true")
    a = ap.parse_args()
    if a.sub:
        build_sub(a.sub.upper(), a.accent or C["amber"])
        if not a.no_video: render_sting(sub=a.sub.upper())
        return
    for th in ("dark", "navy", "light", "mono"):
        p = write(f"svg/mark/mark-{th}.svg", svg(512, 512, mark("k" + th, th))); png(p, 512, 1024)
        p = write(f"svg/mark/mark-simple-{th}.svg", svg(512, 512, simple_mark(th) if th != "mono" else simple_mark("mono"))); png(p, 512)
        p = write(f"svg/primary/horizontal-{th}.svg", lockup_horizontal(th, bgfill=th != "mono")); png(p, 1200, 2400, square=False)
        p = write(f"svg/primary/stacked-{th}.svg", lockup_stacked(th, bgfill=th != "mono")); png(p, 800, 1600, square=False)
        p = write(f"svg/wordmark/wordmark-{th}.svg", wordmark_line(th)); png(p, 1600, square=False)
    for th in ("dark", "navy", "light"):
        p = write(f"svg/icon/app-icon-{th}.svg", app_icon(th)); png(p, 1024, 512, 192, 180)
        p = write(f"svg/icon/favicon-{th}.svg", app_icon(th, simple=True)); png(p, 64, 48, 32, 16)
        p = write(f"svg/secondary/marquee-badge-{th}.svg", marquee_badge(th)); png(p, 1000, 2000, square=False)
    write("svg/animated/mark-animated.svg", animated_svg())
    for sub, acc in list(SUBS.items()): build_sub(sub, acc)
    write("tokens.json", json.dumps(tokens(), indent=2))
    if not a.no_video:
        render_sting(); render_sting(sub="CINEMAS")
    print("done")

if __name__ == "__main__":
    main()
